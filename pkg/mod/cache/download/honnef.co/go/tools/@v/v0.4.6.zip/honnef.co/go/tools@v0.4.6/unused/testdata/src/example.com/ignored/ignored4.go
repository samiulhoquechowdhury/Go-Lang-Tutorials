package pkg

func (t9) fn2() {} //@ used("fn2", true)
